def consumer():
    return "available"
